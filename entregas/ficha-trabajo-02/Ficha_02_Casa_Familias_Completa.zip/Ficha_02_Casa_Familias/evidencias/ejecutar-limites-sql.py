from pathlib import Path
original=Path('/workspace/Casa/CasaFamiliasAndroid/validacion/test_backend.py')
source=original.read_text()
extra='''    extra = Path('/workspace/entregas/ficha-trabajo-02/evidencias/limites.sql')
    output = sql(extra)
    print(next(line.strip() for line in output.splitlines() if '"boundaryChecks"' in line))
'''
source=source.replace('finally:\n',extra+'finally:\n')
exec(compile(source,str(original),'exec'),{'__file__':str(original),'__name__':'__main__'})
