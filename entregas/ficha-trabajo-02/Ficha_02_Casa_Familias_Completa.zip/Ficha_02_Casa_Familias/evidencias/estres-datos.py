from pathlib import Path
from playwright.sync_api import sync_playwright
import ast,json,mimetypes,statistics
web=Path('/workspace/Casa/CasaFamiliasAndroid/app/src/main/assets/web')
out=Path('/workspace/entregas/ficha-trabajo-02/evidencias')
module=ast.parse(Path('/workspace/casa-environment/review-forms.py').read_text())
fixture=next(ast.literal_eval(n.value) for n in module.body if isinstance(n,ast.Assign) and any(isinstance(t,ast.Name) and t.id=='fixture' for t in n.targets))
with sync_playwright() as p:
 browser=p.chromium.launch(executable_path='/usr/bin/chromium',headless=True,args=['--no-sandbox'])
 page=browser.new_page(viewport={'width':390,'height':844});errors=[]
 page.on('pageerror',lambda e:errors.append(str(e)))
 page.add_init_script('window.TEST_ROLE="family"')
 def assets(route):
  name=route.request.url.split('/web/',1)[1].split('?',1)[0];f=web/name
  route.fulfill(status=200 if f.is_file() else 404,content_type=mimetypes.guess_type(name)[0] or 'application/octet-stream',body=fixture.encode() if name=='vendor/supabase.js' else f.read_bytes() if f.is_file() else b'')
 page.route('https://appassets.androidplatform.net/web/**',assets)
 page.goto('https://appassets.androidplatform.net/web/index.html')
 page.wait_for_function('window.CF && CF.state().me && !document.getElementById("startupScreen").hidden === false')
 page.evaluate('document.fonts.ready')
 results=[]
 for n in [100,500,1000]:
  times=[]
  for trial in range(3):
   ms=page.evaluate('''async n=>{
    CF.state().D.payments=Array.from({length:n},(_,i)=>({id:'p'+i,family_id:1,amount:100,paid_at:'2026-10-15',status:'pending',note:'Pago de prueba '+i}));
    const begin=performance.now();Mobile.go('payments');
    await new Promise(r=>requestAnimationFrame(()=>requestAnimationFrame(r)));
    return performance.now()-begin;
   }''',n)
   assert page.locator('#mobileContent [data-pay]').count()==n
   assert not page.evaluate('document.documentElement.scrollWidth>innerWidth')
   assert not page.locator('#startupScreen').is_visible()
   times.append(round(ms,2))
  results.append({'registros':n,'muestrasMs':times,'medianaMs':round(statistics.median(times),2),'tarjetasVisiblesEnDOM':n,'erroresJS':0})
 page.evaluate('Mobile.go("home")');page.screenshot(path=str(out/'inicio-ejemplo.png'))
 page.evaluate('Mobile.go("settings")');page.screenshot(path=str(out/'cuenta-ejemplo.png'))
 assert not errors,errors
 report={'entorno':'Chromium de escritorio sin interfaz, viewport 390x844, datos simulados; no es medición del teléfono ni carga del servidor','muestrasPorNivel':3,'resultados':results,'erroresJS':errors,'result':'PASS'}
 (out/'estres-datos.json').write_text(json.dumps(report,indent=2));print(json.dumps(report))
 browser.close()
