// Ejecutar con Node y jsdom del entorno. Usa solo un servidor simulado en memoria.
const assert=require('node:assert/strict');
const fs=require('node:fs');
const {setup}=require('/workspace/Casa/CasaFamiliasAndroid/validacion/test_admin.cjs');
(async()=>{
 const h=await setup(),bounds=[];
 try{
  for(const [bytes,accepted] of [[0,false],[1,true],[5242880,true],[5242881,false]]){
   const before=h.uploads.length;h.file('image/png',bytes);await h.submit('qrSettingsForm');
   assert.equal(h.uploads.length>before,accepted);
   bounds.push({campo:'bytes de imagen QR',bytes,esperado:accepted?'aceptar':'rechazar',obtenido:accepted?'aceptado por validación de tamaño':'rechazado antes de subir'});
  }
  h.$('renameFamily').value='1';h.change('renameFamily');
  const t=performance.now(),initial=h.calls.length;
  for(let i=0;i<20;i++){h.input('familyNameInput','Familia Prueba '+i);await h.submit('familyNameForm');}
  assert.equal(h.calls.length-initial,20);assert.equal(h.tables.families[0].name,'Familia Prueba 19');
  const repetitive={operaciones:20,rpcRecibidas:h.calls.length-initial,tiempoMs:+(performance.now()-t).toFixed(2),ultimoValorConservado:true};
  h.file();h.hold();const before=h.calls.length;const first=h.submit('qrSettingsForm');
  await new Promise(r=>setTimeout(r,25));for(let i=0;i<19;i++)await h.submit('qrSettingsForm');
  assert.equal(h.calls.length-before,1);h.release();await first;
  const rapid={pulsaciones:20,solicitudesDeGuardado:1,duplicados:0};
  const out={entorno:'Node.js + jsdom; Supabase simulado, sin red',limitesQR:bounds,repetitivas:repetitive,pulsacionesRapidas:rapid,result:'PASS'};
  fs.writeFileSync('/workspace/entregas/ficha-trabajo-02/evidencias/limites-repeticiones.json',JSON.stringify(out,null,2));console.log(JSON.stringify(out));
 }finally{h.dom.window.close()}
})().catch(e=>{console.error(e);process.exitCode=1});
