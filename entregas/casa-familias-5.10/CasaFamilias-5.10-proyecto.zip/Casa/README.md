# Casa Familias

Entrega actual: **5.10, letra grande y acceso directo al recordatorio de limpieza**. Consulta [la entrega y los pendientes](ENTREGA.md), [las instrucciones de instalación y actualización web](entregas/casa-familias-5.10/LEEME.md) y [la guía de publicación](entregas/google-play/GUIA_GOOGLE_PLAY.md).

En **Cuenta**, los controles **Normal, Grande y Extra grande** son botones de ancho completo al principio de la pantalla. Toda la fila Modo oscuro responde al toque. En **Limpieza → Activar recordatorio** se permite el aviso de la semana en ese celular; **Probar aviso de limpieza** comprueba su canal de Android. Si está bloqueado, el botón abre los ajustes correspondientes. El inicio descarta semanas antiguas al buscar el próximo turno. [Guía de activación](entregas/casa-familias-5.10/LEEME.md).

El inicio ofrece botones grandes con una tarea por botón. Para las familias: **Pagar**, **Ver mis deudas**, **Mis pagos** y su próxima limpieza. Para administración y encargado: **Registrar facturas**, **Revisar pagos**, **Ver deudas** y **Limpieza esta semana**. El pago se hace en tres pasos: importe, foto y revisión. Los detalles y opciones poco frecuentes se abren cuando se necesitan. Las deudas muestran cuánto falta en cada mes y hasta qué mes existen registros. El texto de navegación se adapta y los botones admiten varias líneas.

La web comparte colores, tipografía, tarjetas, menús y formularios guiados con la aplicación nativa. El ZIP de la entrega contiene `index.html` en la raíz para actualizar el sitio existente en Netlify. **La web publicada no se ha desplegado desde este entorno:** el propietario debe subir la carpeta descomprimida en Deploys de su sitio `casafliagalarza`. Usa el mismo proyecto Supabase; no necesita migraciones para este cambio visual. Las pruebas de 5.9 utilizan datos ficticios y no crean pagos ni cambian saldos reales.

Gastos abre todos los meses, del más reciente al antiguo, y destaca hasta qué mes se registraron servicios. Distingue **total de facturas** de **total repartido**. La regla nueva suma agua + luz + gas + internet, resta únicamente descuentos explícitos y divide entre las seis cuentas; no recorta por promedios ni genera cobros automáticos al restaurante. El gas de la hoja enero-junio 2026 es cero. La pantalla de cuenta muestra el último mes publicado antes del saldo y tarjetas cortas con el pendiente de cada mes.

**Corrección aplicada en Supabase el 28 de octubre de 2026 (Bolivia):** la migración 010 y la reparación de enero-junio ya están verificadas. El semestre suma Bs2.250,50, con gas cero y reparto completo entre las seis cuentas. Se conservaron los 36 registros de pago anteriores, fotos y fechas; se añadieron únicamente 12 coberturas automáticas faltantes del encargado, sin registrar depósitos nuevos. Sus dos cuentas quedan en cero. Los demás meses permanecen iguales. La copia privada y la auditoría quedaron guardadas. [Verificación del despliegue](entregas/casa-familias-5.8/evidencias/backend-deployment.json). No repitas la reparación durante setup.

En los campos de factura/comprobante, **Tomar foto** abre la cámara del teléfono y devuelve la imagen al formulario; **Elegir de galería** sigue disponible. Se orienta y reduce la foto antes de enviarla al guardar. **Mi cuenta** muestra el último mes con gastos publicados, el primero pendiente y tarjetas por mes: Al día, Pago parcial o Pendiente. No marca como pagados los meses sin registro. **Pagos** distingue el estado de revisión de cada comprobante y los meses que cubre.

En **Inicio → Pagar**, «Mis deudas más antiguas» reparte el depósito por mes y muestra cuánto quedaría pendiente. Tres meses de Bs80 y un depósito de Bs200 se reparten 80/80/40: quedan Bs40. Se adjunta una sola foto y el encargado revisa el depósito completo. El servidor recalcula al aprobar, guarda el crédito si sobra e impide duplicar la solicitud al reintentar. El historial muestra el depósito una vez; los reportes conservan las asignaciones contables.

Para los avisos del celular: **Cuenta → Activar notificaciones**, permite el permiso de Android y pulsa **Probar notificación**. WorkManager revisa la semana de limpieza, nuevas deudas, vencimientos y publicaciones de servicios con la app cerrada. Es sincronización periódica con intervalo mínimo de 15 minutos, sujeta a batería y conexión; **no es push instantáneo**. Cerrar sesión o desactivar la opción detiene los avisos en ese teléfono. Consulta [la instalación y las funciones actuales](entregas/casa-familias-5.8/LEEME.md).

En **Inicio** y **Limpieza**, el ingeniero/administrador y encargado consultan quién limpia esta semana y el calendario de todas las familias. Los intercambios solo se solicitan para una familia propia y los responde otra persona de la familia receptora; el rol administrativo no da permiso para decidir por familias ajenas.

Después de iniciar sesión, entra en **Cuenta → Activar huella** y confirma con la biometría de Android. Necesita un lector compatible y una huella previamente registrada. La opción se activa solo para la cuenta de ese teléfono; no se puede habilitar remotamente para los otros celulares. La contraseña sigue disponible. Se solicita autenticación al reiniciar el proceso o regresar tras 30 segundos fuera de la app. Consulta [la instalación y sus límites](entregas/casa-familias-5.3/LEEME.md).

La interfaz utiliza Kotlin, Jetpack Compose, Material 3, Navigation Compose y MVVM. Incluye azul, fondos claros, botones con iconos y texto, Inter, tema claro y oscuro y letras ampliables. Las familias tienen cuatro pestañas: Inicio, Deudas, Limpieza y Más; administración y encargado: Inicio, Gastos, Deudas y Más. Pagos y Mi cuenta también se encuentran en Más. Las [capturas históricas de 5.9](entregas/casa-familias-5.9/capturas) muestran datos ficticios; las propuestas y auditorías de versiones anteriores son históricas.

Conserva Supabase, cuentas, cuotas, pagos parciales, crédito, comprobantes, QR privado, nombres y asignaciones de familias, limpieza semanal, propuestas, avisos, cierre de meses, auditoría y reportes PDF/Excel. Fondo Común no aparece en las consultas ni en las rutas activas. Los datos históricos no se eliminan.

El ciclo semanal sigue siendo **Choque → Galarza → Salinas → David → Acha**. Salinas y Salinas2 comparten limpieza; sus registros contables permanecen separados. Las funciones familiares de propuestas, votación e intercambio tienen comprobaciones de propiedad en Supabase.

El código actual está en **CasaFamiliasAndroid/**. `CasaFamiliasAndroid.zip` y las fichas de la versión anterior se conservan como archivos históricos. El APK de presentación se compila con `assemblePresentation`, optimizado y con el certificado de pruebas anterior. La variante `release` utiliza una clave de subida propia cuando se configura localmente; sin esa clave, el AAB queda sin firmar y no se puede enviar a Google Play. Android 8 o posterior, destino Android 16/API 36. La aplicación sigue configurada para una sola casa y sus cuentas autorizadas.

## Tener el proyecto en tu computadora

La opción más sencilla es GitHub Desktop:

1. Instala [GitHub Desktop](https://desktop.github.com/) e inicia sesión con tu cuenta de GitHub.
2. Elige **File → Clone repository → URL** y pega `https://github.com/achaalex326-ux/Casa.git`.
3. Elige una carpeta nueva para guardar el repositorio. Conserva tu carpeta anterior mientras compruebas que tienes todos tus archivos.
4. Abre la carpeta `CasaFamiliasAndroid` del repositorio clonado en Android Studio.
5. Cuando haya cambios hechos desde Codex o GitHub, pulsa **Fetch origin** y luego **Pull origin** en GitHub Desktop. Se actualizarán los archivos de esta carpeta.
6. Cuando edites archivos en tu computadora, escribe un resumen del cambio, pulsa **Commit to main** y después **Push origin** para subirlos a GitHub. Si tienes cambios locales pendientes, guárdalos con un commit antes de hacer Pull y resuelve cualquier conflicto que GitHub Desktop indique.

Si tienes archivos adicionales en tu carpeta anterior que no venían en el ZIP, copia solo esos archivos de tu proyecto al repositorio clonado, comprueba los cambios en GitHub Desktop y haz Commit y Push. No copies carpetas `.git`, cachés, contraseñas ni claves de firma.

Si prefieres la terminal y tienes Git instalado:

```bash
git clone https://github.com/achaalex326-ux/Casa.git
cd Casa
```

Para descargar cambios de GitHub, desde esa carpeta y con tus cambios locales guardados:

```bash
git pull --ff-only origin main
```

## Compilar y probar

Consulta [las instrucciones de Android Studio](CasaFamiliasAndroid/README_ABRIR_EN_ANDROID_STUDIO.md). El proyecto requiere JDK 17, Gradle 8.11.1 y Android SDK Platform 36.

En macOS/Linux, desde `CasaFamiliasAndroid`:

```bash
./gradlew assembleDebug
```

En Windows:

```bat
gradlew.bat assembleDebug
```

Pruebas nativas, desde `CasaFamiliasAndroid`:

```bash
./gradlew testDebugUnitTest lintDebug assemblePresentation bundleRelease
./gradlew connectedDebugAndroidTest
```

La segunda orden necesita un dispositivo o emulador Android. Pruebas web: desde `CasaFamiliasAndroid/validacion`, instala las dependencias con `npm install --no-package-lock` y ejecuta `npm test`. Validan el código web actual con un servidor simulado; no prueban Compose. Pruebas SQL con Python 3 y Docker: `python test_backend.py`. Usan PostgreSQL desechable; los fixtures nunca se ejecutan en Supabase real. El conjunto financiero reproduce el fallo de registro mensual, prueba la regularización idempotente y comprueba que ambas familias del encargado tienen su cuota de servicios cubierta sin afectar otras deudas.

En el entorno de Codex, las herramientas y las dependencias ya preparadas se activan así:

```bash
source /workspace/casa-environment/activate.sh
cd "$CASA_PROJECT"
gradle --no-daemon --max-workers=2 --console=plain testDebugUnitTest assembleDebug
```
